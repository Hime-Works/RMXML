class Encoding
  ASCII_8BIT = "ASCII-8BIT"
  UTF_8 = "UTF-8"
end